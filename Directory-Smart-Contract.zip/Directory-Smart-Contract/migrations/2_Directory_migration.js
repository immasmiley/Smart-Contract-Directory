const Directory = artifacts.require("Directory");

module.exports = function (deployer) {
  deployer.deploy(Directory);
};
